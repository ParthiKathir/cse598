﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;

//***********************************
//Primary Name: Parthipan Kathiresan
//ASU ID(emplid):1214662163
//ASURITE User ID:pkathire
//E-mail id: pkathire @asu.edu
//Course: CSE598 / SW Integration & Engr (2021 Spring)
//Graduate Program: MSE
//* ***********************************

namespace WcfClientConsole
{
    class Program
    {
        static void Main(string[] args)
        {
          
            

            //(1) Create a proxy to the WCF service.
            myInterfaceClient myPxy = new myInterfaceClient();

            //(2) Call the service operations through the proxy
            Console.WriteLine("Please enter the Lower Limit");

            //int low = 22;
            int low = Convert.ToInt32(Console.ReadLine());
            //int high = 49;
            Console.WriteLine("Please enter the Upper Limit");
            int high = Convert.ToInt32(Console.ReadLine());
           

            int secret = myPxy.SecretNumber(low, high);

            Console.WriteLine("Enter your guess");
           int  userNum = Convert.ToInt32( Console.ReadLine());
            String output = myPxy.checkNumber(userNum,secret);



            Console.WriteLine("Secret Number is  = {0}", secret);
            Console.WriteLine("The check number is {0}  ", output);

            // Close the proxy, the channel to the service
            //Console.ReadLine();
            myPxy.Close();
            Console.WriteLine("/n Press <Enter> to terminate the client. /n");
            Console.ReadLine();
        }
    }
}
