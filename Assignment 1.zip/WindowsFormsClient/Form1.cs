﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//***********************************
//Primary Name: Parthipan Kathiresan
//ASU ID(emplid):1214662163
//ASURITE User ID:pkathire
//E-mail id: pkathire @asu.edu
//Course: CSE598 / SW Integration & Engr (2021 Spring)
//Graduate Program: MSE
//* ***********************************

namespace WindowsFormsClient
{
    
    public partial class Form1 : Form
    {
        ServiceRefer.myInterfaceClient refClient = new ServiceRefer.myInterfaceClient();

        // Global variables for the two button clicks. Declared before initializing the form.
        int secret;
        int low;
        int high;
        int guess;
        int count;



        public Form1()
        {
            InitializeComponent();
        }

        private void btnGen_Click(object sender, EventArgs e)
        {

            
         low = Convert.ToInt32(lowBox.Text);
         high = Convert.ToInt32(upBox.Text);
            

          secret = refClient.SecretNumber(low, high);
        }

        private void btnPlay_Click(object sender, EventArgs e)
        {

            // Running count of how may times the random number was guessed.
            count++;
            if (guessBox != null)
            {
                guess = Convert.ToInt32(guessBox.Text);


                string checkNum = refClient.checkNumber(guess, secret).ToString();
                Console.WriteLine(lblNumber.Text = checkNum);
            }
            Attempts.Text = count.ToString();
        }
    }
}
