﻿
namespace WindowsFormsClient
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lowBox = new System.Windows.Forms.TextBox();
            this.upBox = new System.Windows.Forms.TextBox();
            this.btnGen = new System.Windows.Forms.Button();
            this.guessBox = new System.Windows.Forms.TextBox();
            this.btnPlay = new System.Windows.Forms.Button();
            this.Attempts = new System.Windows.Forms.Label();
            this.lblNumber = new System.Windows.Forms.Label();
            this.lblGuess = new System.Windows.Forms.Label();
            this.lblLower = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblUpper = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lowBox
            // 
            this.lowBox.Location = new System.Drawing.Point(109, 59);
            this.lowBox.Name = "lowBox";
            this.lowBox.Size = new System.Drawing.Size(100, 20);
            this.lowBox.TabIndex = 0;
            this.lowBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // upBox
            // 
            this.upBox.Location = new System.Drawing.Point(313, 58);
            this.upBox.Name = "upBox";
            this.upBox.Size = new System.Drawing.Size(100, 20);
            this.upBox.TabIndex = 1;
            this.upBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnGen
            // 
            this.btnGen.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnGen.Location = new System.Drawing.Point(510, 58);
            this.btnGen.Name = "btnGen";
            this.btnGen.Size = new System.Drawing.Size(177, 23);
            this.btnGen.TabIndex = 2;
            this.btnGen.Text = "Generate a Secret Number";
            this.btnGen.UseVisualStyleBackColor = true;
            this.btnGen.Click += new System.EventHandler(this.btnGen_Click);
            // 
            // guessBox
            // 
            this.guessBox.Location = new System.Drawing.Point(165, 137);
            this.guessBox.Name = "guessBox";
            this.guessBox.Size = new System.Drawing.Size(100, 20);
            this.guessBox.TabIndex = 3;
            // 
            // btnPlay
            // 
            this.btnPlay.Location = new System.Drawing.Point(313, 135);
            this.btnPlay.Name = "btnPlay";
            this.btnPlay.Size = new System.Drawing.Size(75, 23);
            this.btnPlay.TabIndex = 4;
            this.btnPlay.Text = "Play";
            this.btnPlay.UseVisualStyleBackColor = true;
            this.btnPlay.Click += new System.EventHandler(this.btnPlay_Click);
            // 
            // Attempts
            // 
            this.Attempts.AutoSize = true;
            this.Attempts.Location = new System.Drawing.Point(414, 141);
            this.Attempts.Name = "Attempts";
            this.Attempts.Size = new System.Drawing.Size(48, 13);
            this.Attempts.TabIndex = 5;
            this.Attempts.Text = "Attempts";
            // 
            // lblNumber
            // 
            this.lblNumber.AutoSize = true;
            this.lblNumber.Location = new System.Drawing.Point(549, 140);
            this.lblNumber.Name = "lblNumber";
            this.lblNumber.Size = new System.Drawing.Size(74, 13);
            this.lblNumber.TabIndex = 6;
            this.lblNumber.Text = "The number is";
            // 
            // lblGuess
            // 
            this.lblGuess.AutoSize = true;
            this.lblGuess.Location = new System.Drawing.Point(45, 140);
            this.lblGuess.Name = "lblGuess";
            this.lblGuess.Size = new System.Drawing.Size(76, 13);
            this.lblGuess.TabIndex = 7;
            this.lblGuess.Text = "Make a Guess";
            // 
            // lblLower
            // 
            this.lblLower.AutoSize = true;
            this.lblLower.Location = new System.Drawing.Point(45, 66);
            this.lblLower.Name = "lblLower";
            this.lblLower.Size = new System.Drawing.Size(60, 13);
            this.lblLower.TabIndex = 8;
            this.lblLower.Text = "Lower Limit";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 23);
            this.label2.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(0, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 23);
            this.label3.TabIndex = 0;
            // 
            // lblUpper
            // 
            this.lblUpper.AutoSize = true;
            this.lblUpper.Location = new System.Drawing.Point(247, 63);
            this.lblUpper.Name = "lblUpper";
            this.lblUpper.Size = new System.Drawing.Size(60, 13);
            this.lblUpper.TabIndex = 9;
            this.lblUpper.Text = "Upper Limit";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblUpper);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblLower);
            this.Controls.Add(this.lblGuess);
            this.Controls.Add(this.lblNumber);
            this.Controls.Add(this.Attempts);
            this.Controls.Add(this.btnPlay);
            this.Controls.Add(this.guessBox);
            this.Controls.Add(this.btnGen);
            this.Controls.Add(this.upBox);
            this.Controls.Add(this.lowBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox lowBox;
        private System.Windows.Forms.TextBox upBox;
        private System.Windows.Forms.Button btnGen;
        private System.Windows.Forms.TextBox guessBox;
        private System.Windows.Forms.Button btnPlay;
        private System.Windows.Forms.Label Attempts;
        private System.Windows.Forms.Label lblNumber;
        private System.Windows.Forms.Label lblGuess;
        private System.Windows.Forms.Label lblLower;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblUpper;
    }
}

