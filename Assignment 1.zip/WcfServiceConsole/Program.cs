﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using System.ServiceModel.Description;
//***********************************
//Primary Name: Parthipan Kathiresan
//ASU ID(emplid):1214662163
//ASURITE User ID:pkathire
//E-mail id: pkathire @asu.edu
//Course: CSE598 / SW Integration & Engr (2021 Spring)
//Graduate Program: MSE
//* ***********************************

namespace WcfServiceConsole
{

    namespace SelfHostingService
    {
        [ServiceContract]

        // Use this Interface to define contracts
        public interface myInterface
        {
            [OperationContract]
            int SecretNumber(int lower, int upper);

            [OperationContract]
            string checkNumber(int userNum, int SecretNum);
        }
        // Implementation of Interfaces
        [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall)]
        public class myService : myInterface
        {

            public int SecretNumber(int lower, int upper)
            {
                DateTime currentDate = DateTime.Now;
                int seed = (int)currentDate.Ticks;
                Random random = new Random(seed);
                int sNumber = random.Next(lower, upper);
                return sNumber;
            }
            public string checkNumber(int userNum, int SecretNum)
            {
                if (userNum == SecretNum) return "correct";
                else if (userNum > SecretNum) return "too big";
                else return "too small";
            }

        }

        // Self Hosting code is programmed below.
        class Program
        {
            static void Main(string[] args)
            {
                // (1) Create a URI instance to myService as the base address.
                Uri baseAddress = new Uri("http://localhost:8000/Service");

                // (2) a new ServiceHost instance to host the service with address
                ServiceHost selfHost = new ServiceHost(typeof(myService),baseAddress);

                try
                {
                    // (3) Add a service endpoint with contract and binding

                    selfHost.AddServiceEndpoint(typeof(myInterface), new WSHttpBinding(), "myService");

                    // (4) Add metadata for platform-independent access.
                    System.ServiceModel.Description.ServiceMetadataBehavior smb = new System.ServiceModel.Description.ServiceMetadataBehavior();
                    smb.HttpGetEnabled = true; // enable the metadata
                    selfHost.Description.Behaviors.Add(smb);//Add here

                    // (5) Start the service and waiting for request.
                    selfHost.Open();
                    Console.WriteLine("myService is ready to take requests. Please create a client to call my SecretNumber(int lower, int upper) service or checkNumber(int userNum, int SecretNum) sevice.");
                    Console.WriteLine("If you want to quit this service, simply press <ENTER>. \n");

                    Console.ReadLine();

                    // (6) Close the ServiceHostBase to shutdown the service.
                    selfHost.Close();
                        




                }
                catch (CommunicationException ce)
                {
                    Console.WriteLine("An exception occurred: {0}", ce.Message);
                    selfHost.Abort();
                }
            }
        }
    }
   
}
